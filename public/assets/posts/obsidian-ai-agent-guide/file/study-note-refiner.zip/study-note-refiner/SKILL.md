---
name: study-note-refiner
description: Refine exam-oriented learning notes under Study/. Use when the user asks to summarize raw notes, screenshots, PDFs, videos, or files into atomic Obsidian notes; fill source-note summaries; create or maintain chapter indexes; read the subject's bound template note; and maintain homepage/index links. If the subject homepage or template binding is missing, this skill must explicitly hand off to study-direction-init, complete only the missing initialization, and then return to refinement.
---

# Study Note Refiner

Use this skill only for learning and exam-oriented notes under `Study/`.

## Core Workflow

1. Determine the current subject context from the file path under `Study/`.
2. Run a preflight check before deep refining:
   - check whether the subject homepage exists,
   - check whether `template_family` is present,
   - check whether `template_note` is present.
3. If any of the above are missing, stop refinement, explicitly open `../study-direction-init/SKILL.md`, follow that skill to fill only the missing parts, and then return to this workflow.
4. Lock onto the user-specified heading range if provided.
5. Read the source text, assets, and user comments in that range.
6. Read the resolved subject homepage frontmatter and `template_note`.
7. Split content into atomic notes according to the template note, treating it as a maximal example rather than a rigid schema.
8. Preserve source assets near the relevant source or note context.
9. Fill `本次已整理出的原子笔记` and `本节可直接复习的结论`.
10. Maintain the subject homepage and related chapter indexes.

## Required References

Read these references before editing files:

- `references/workflow.md`
- `references/template-resolution.md`
- `references/atomicity-and-linking.md`
- `references/asset-handling.md`
- `references/homepage-index-maintenance.md`
- `references/homepage-frontmatter.md`

Open `../study-direction-init/SKILL.md` only when the preflight check fails.

## Boundaries

- Do not apply outside `Study/`.
- Do not turn a lesson into one large lecture note.
- Do not require per-note template files when the template note already defines sufficient guidance.
- Do not delete source assets.
- Do not create placeholder links unless they represent real future knowledge nodes.
- Do not continue refining when the subject homepage or template binding is missing; hand off to `study-direction-init` first.