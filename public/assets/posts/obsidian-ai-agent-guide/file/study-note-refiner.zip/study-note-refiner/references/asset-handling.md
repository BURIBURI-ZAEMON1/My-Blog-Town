# Asset Handling

Source material can include:

- Screenshots
- PDF
- Markdown
- docx
- Video
- User remarks

Rules:

- Preserve original assets.
- Understand asset content and user remarks together before refining.
- Keep asset embeds near the relevant source or note context when possible.
- Do not move all assets to the end of the note.
- If assets are moved, update references.
- Do not delete source assets during note refinement.

The vault may store assets in a root-level `assets/` folder. Respect existing Obsidian attachment settings.
