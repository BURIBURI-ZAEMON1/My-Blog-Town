# Workflow

Source notes usually contain multiple sessions separated by level-1 headings.

Expected session sections:

- `本次已整理出的原子笔记`
- `原始速记`
- `本节可直接复习的结论`

When the user specifies a heading:

- Process only that heading and its content until the next same-level heading.
- If the user provides only a date-like heading such as `26-05-09`, match it only when unique.
- If the requested heading is missing, find the closest same-level heading and ask only if ambiguity affects edits.

Normalization:

- Promote a session title to level 1 if it was written at the wrong level.
- Add missing standard sections.
- Fix obvious heading-level mistakes.

Preflight gate:

1. Determine the current subject from the note path under `Study/`.
2. Check whether the subject homepage exists.
3. Check whether the subject homepage contains `template_family`.
4. Check whether the subject homepage contains `template_note`.
5. If any of these are missing, explicitly open `../study-direction-init/SKILL.md`, initialize only the missing parts, and return to this workflow.

Refining sequence:

1. Complete the preflight gate.
2. Lock the target session range.
3. Read related assets and user remarks.
4. Resolve the template note through the subject homepage.
5. Create or update atomic notes.
6. Update the source note's atomic-note list and review conclusions.
7. Maintain related indexes and homepages.