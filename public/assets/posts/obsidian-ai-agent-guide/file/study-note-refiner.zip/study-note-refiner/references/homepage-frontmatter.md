# Homepage Frontmatter

Use subject homepage frontmatter to resolve the template note.

Example:

```yaml
---
title: 高数-首页
tags:
  - study
type: home
direction_name: 高数
direction_level: subject
subject_name: 高数
parent_home: "[[Math-首页]]"
template_family: Math
template_note: "[[模板-Math]]"
exam_oriented: true
---
```

Required for subject homepages:

- `title`
- `type: home`
- `direction_name`
- `direction_level: subject`
- `subject_name`
- `parent_home`
- `template_family`
- `template_note`
- `exam_oriented: true`

Optional but recommended:

- `tags`

Legacy compatibility fields may remain temporarily:

- `template_root`
- `template_index`