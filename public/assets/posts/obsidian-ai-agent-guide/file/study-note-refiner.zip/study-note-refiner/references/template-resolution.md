# Template Resolution

Resolve templates in this order:

1. Read the current subject homepage frontmatter.
2. If the subject homepage does not exist, do not continue refinement. Explicitly open `../study-direction-init/SKILL.md`, fill only the missing initialization, and then return here.
3. Use `template_note` when it exists.
4. If `template_note` is missing, fall back to legacy fields such as `template_root` and `template_index` only for compatibility.
5. If neither the preferred field nor a legacy binding exists, do not guess a template. Explicitly open `../study-direction-init/SKILL.md`, complete only the missing binding, and then return here.

Subject homepage preferred fields:

- `template_family`
- `template_note`

Legacy compatibility fields:

- `template_root`
- `template_index`

Template note minimum frontmatter:

    ---
    title: 模板-Math
    type: template-note
    template_family: Math
    ---

Template note body should declare:

- Applicable subjects
- Index rules
- Supported note types
- Simplification principles
- Whether lightweight supporting notes are allowed

Output policy:

- Use the resolved template note as the authority for note types and index structure.
- Treat the template note as a maximal example, not a rigid schema.
- The agent may omit low-value sections.
- The agent should simplify aggressively when the knowledge point is narrow.
- The agent may create lightweight supporting notes when a small dependency point is necessary for understanding.
- Missing homepage or missing binding is a blocking condition, not permission to continue with guessing.