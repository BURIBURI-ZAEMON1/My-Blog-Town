# Atomicity And Linking

Atomicity:

- Each atomic note should serve one stable knowledge object.
- Do not put multiple parallel problem types, unrelated rules, or separate chapter themes in one note.
- If a note needs several independent headings to be coherent, split it.
- Note titles should name the knowledge object directly, not `第一节`, `补充`, or `例题`.

Linking:

- Use Obsidian wikilinks.
- Prefer putting `[[links]]` inside the sentence where the relationship actually matters.
- Do not default to standalone sections such as `关联概念`, `关联规则`, `关联题型`, `相关公式`.
- Use standalone relation lists mainly for index notes, source notes, or when several high-value links cannot be expressed naturally in prose.
- Each new atomic note should still have at least one meaningful relationship link.
- Link obvious prerequisites.
- Link the owning chapter index when it exists.
- Explicitly link strong relationships such as `规则-题型`, `概念-易错点`, and `公式-题型`.

Knowledge Expansion:

- The agent may proactively create a missing supporting note when the concept is necessary to understand the current note.
- By default, create a lightweight supporting note first, not a full concept/rule/pattern note.
- Upgrade it to a full note only when the concept itself is independently testable, repeatedly reused, or needs multi-part explanation.
- The missing concept should also satisfy at least one of these conditions:
  - it is likely to be tested,
  - it is a common confusion point,
  - it will probably recur across multiple notes.
- The new note should be explainable in a short standalone form.
- Default budget: create at most 1 to 3 proactive supporting notes per refined session.
- Do not create proactive notes for generic nouns, obvious syntax tokens, or one-off terms with no independent review value.

Programming Detail:

- For programming subjects, when runtime behavior, parameter passing, object state, scope, binding, syntax rules, or code execution order are central, prefer adding a short code snippet.
- Use short snippets to explain behavior, not to pad the note.
- If the user's exam need is mainly classification or distinction, prefer a short supporting note over a long explanatory note.

Placeholder links:

- Do not create placeholder links mechanically.
- Leave a placeholder only when the missing note is a real future knowledge node.
- Prefer fewer meaningful links over dense but vague graph edges.