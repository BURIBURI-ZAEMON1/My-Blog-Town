# Homepage And Index Maintenance

After refining, maintain:

- Current subject homepage.
- The owning chapter index.
- Strongly related existing indexes.

Maintenance actions:

- Add links to new atomic notes.
- Remove clearly stale or duplicated links.
- Improve grouping and short summaries.
- Rename an index only when its name has become too narrow for the content it now owns.

Rename rule:

- Preserve the old name as an alias or compatibility entry when renaming an index.

Index standard:

- A chapter index is a standard output when a session clearly belongs to a chapter, when several atomic notes share one topic, or when the topic will likely receive future additions.
- The specific index structure comes from the active template note.
